## Updating apt repositories

execute "apt-update" do
  command "apt-get update"
end

