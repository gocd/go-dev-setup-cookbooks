subversion Cookbook CHANGELOG
=============================
This file is used to list changes made in each version of the subversion cookbook.


v1.1.2
------
### Improvement
- **[COOK-3868](https://tickets.opscode.com/browse/COOK-3868)** - add mod_dav to subversion cookbooks


v1.1.0
------
### Improvement
- **[COOK-3692](https://tickets.opscode.com/browse/COOK-3692)** - Use SVNParentPath for Server and expose SVNListParentPath as attribute


v1.0.4
------
### Improvement
- **[COOK-3061](https://tickets.opscode.com/browse/COOK-3061)** - Clean up case platform

v1.0.2
------
- Resolves foodcritic warnings
- [COOK-1513] - support SUSE SLES

v1.0.0
------
- [COOK-810] - add Windows platform support

v0.8.3
------
- Current public release
